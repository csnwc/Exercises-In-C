#include <string.h>
#include <ctype.h>

void conceal(const char input[], char output[])
{
}
