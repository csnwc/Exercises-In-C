#include <stdio.h>

#define Y 20
#define X 20

int inkblot(int a[Y][X], int sx, int sy, int ex, int ey)
{
}
